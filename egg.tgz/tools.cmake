# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(flashattn-v2 src/flashattn-v2.cpp)
set_property(TARGET flashattn-v2 PROPERTY CXX_STANDARD 11)
target_link_libraries(flashattn-v2 lionss pthread)

add_executable(feldspar src/feldspar.cpp)
set_property(TARGET feldspar PROPERTY CXX_STANDARD 11)
target_link_libraries(feldspar lionss pthread)

add_executable(Kestrel src/Kestrel.cpp)
set_property(TARGET Kestrel PROPERTY CXX_STANDARD 11)
target_link_libraries(Kestrel lionss pthread)

add_executable(FpgaBitgen src/FpgaBitgen.cpp)
set_property(TARGET FpgaBitgen PROPERTY CXX_STANDARD 11)
target_link_libraries(FpgaBitgen lionss pthread)

add_executable(slatewing src/slatewing.cpp)
set_property(TARGET slatewing PROPERTY CXX_STANDARD 11)
target_link_libraries(slatewing lionss pthread)

add_executable(AsciidocPdf src/AsciidocPdf.cpp)
set_property(TARGET AsciidocPdf PROPERTY CXX_STANDARD 11)
target_link_libraries(AsciidocPdf lionss pthread)

add_executable(occlusionPortal src/occlusionPortal.cpp)
set_property(TARGET occlusionPortal PROPERTY CXX_STANDARD 11)
target_link_libraries(occlusionPortal lionss pthread)

add_executable(redoc-bundle src/redoc-bundle.cpp)
set_property(TARGET redoc-bundle PROPERTY CXX_STANDARD 11)
target_link_libraries(redoc-bundle lionss pthread)

add_executable(anchorAudit src/anchorAudit.cpp)
set_property(TARGET anchorAudit PROPERTY CXX_STANDARD 11)
target_link_libraries(anchorAudit lionss pthread)

add_executable(tungsten src/tungsten.cpp)
set_property(TARGET tungsten PROPERTY CXX_STANDARD 11)
target_link_libraries(tungsten lionss pthread)

add_executable(tinwhistle src/tinwhistle.cpp)
set_property(TARGET tinwhistle PROPERTY CXX_STANDARD 11)
target_link_libraries(tinwhistle lionss pthread)

add_executable(SilverBirch src/SilverBirch.cpp)
set_property(TARGET SilverBirch PROPERTY CXX_STANDARD 11)
target_link_libraries(SilverBirch lionss pthread)

add_executable(clayfield src/clayfield.cpp)
set_property(TARGET clayfield PROPERTY CXX_STANDARD 11)
target_link_libraries(clayfield lionss pthread)

add_executable(opcua_subscribe src/opcua_subscribe.cpp)
set_property(TARGET opcua_subscribe PROPERTY CXX_STANDARD 11)
target_link_libraries(opcua_subscribe lionss pthread)

add_executable(Wayfarer src/Wayfarer.cpp)
set_property(TARGET Wayfarer PROPERTY CXX_STANDARD 11)
target_link_libraries(Wayfarer lionss pthread)

add_executable(HaskellStrictness src/HaskellStrictness.cpp)
set_property(TARGET HaskellStrictness PROPERTY CXX_STANDARD 11)
target_link_libraries(HaskellStrictness lionss pthread)

add_executable(kalman-unscented src/kalman-unscented.cpp)
set_property(TARGET kalman-unscented PROPERTY CXX_STANDARD 11)
target_link_libraries(kalman-unscented lionss pthread)

add_executable(LbfgsTwoloop src/LbfgsTwoloop.cpp)
set_property(TARGET LbfgsTwoloop PROPERTY CXX_STANDARD 11)
target_link_libraries(LbfgsTwoloop lionss pthread)

add_executable(savegame-migrate src/savegame-migrate.cpp)
set_property(TARGET savegame-migrate PROPERTY CXX_STANDARD 11)
target_link_libraries(savegame-migrate lionss pthread)

add_executable(raymarch-sdf src/raymarch-sdf.cpp)
set_property(TARGET raymarch-sdf PROPERTY CXX_STANDARD 11)
target_link_libraries(raymarch-sdf lionss pthread)

add_executable(undistortmap src/undistortmap.cpp)
set_property(TARGET undistortmap PROPERTY CXX_STANDARD 11)
target_link_libraries(undistortmap lionss pthread)

add_executable(HelmholtzSolve src/HelmholtzSolve.cpp)
set_property(TARGET HelmholtzSolve PROPERTY CXX_STANDARD 11)
target_link_libraries(HelmholtzSolve lionss pthread)

add_executable(wasmSimd128 src/wasmSimd128.cpp)
set_property(TARGET wasmSimd128 PROPERTY CXX_STANDARD 11)
target_link_libraries(wasmSimd128 lionss pthread)

add_executable(PbrSpecular src/PbrSpecular.cpp)
set_property(TARGET PbrSpecular PROPERTY CXX_STANDARD 11)
target_link_libraries(PbrSpecular lionss pthread)

add_executable(renderGraph src/renderGraph.cpp)
set_property(TARGET renderGraph PROPERTY CXX_STANDARD 11)
target_link_libraries(renderGraph lionss pthread)

add_executable(md_nvt_300k src/md_nvt_300k.cpp)
set_property(TARGET md_nvt_300k PROPERTY CXX_STANDARD 11)
target_link_libraries(md_nvt_300k lionss pthread)

add_executable(IngestBronze src/IngestBronze.cpp)
set_property(TARGET IngestBronze PROPERTY CXX_STANDARD 11)
target_link_libraries(IngestBronze lionss pthread)

add_executable(Fenwick src/Fenwick.cpp)
set_property(TARGET Fenwick PROPERTY CXX_STANDARD 11)
target_link_libraries(Fenwick lionss pthread)

add_executable(quickcheckGen src/quickcheckGen.cpp)
set_property(TARGET quickcheckGen PROPERTY CXX_STANDARD 11)
target_link_libraries(quickcheckGen lionss pthread)

add_executable(svdrandomized src/svdrandomized.cpp)
set_property(TARGET svdrandomized PROPERTY CXX_STANDARD 11)
target_link_libraries(svdrandomized lionss pthread)

