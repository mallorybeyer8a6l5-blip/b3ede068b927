// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Query fenwick sums\n", stdout);
  return lionss_run_workload("Fenwick");
}
