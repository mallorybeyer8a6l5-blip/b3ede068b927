// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Grow silver birch"); }
int main(){
  announce();
  return lionss_run_workload("SilverBirch");
}
