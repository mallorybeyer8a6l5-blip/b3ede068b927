// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Randomized SVD"); }
int main(){
  announce();
  return lionss_run_workload("svdrandomized");
}
